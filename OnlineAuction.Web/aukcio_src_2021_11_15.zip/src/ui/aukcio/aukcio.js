import React, { useEffect, useState } from "react";

import Button from "@mui/material/Button";
import { Grid } from "@material-ui/core";
import Box from "@mui/material/Box";
import Input from "@mui/material/Input";
import Toolbar from "@mui/material/Toolbar";
import TextField from "@mui/material/TextField";
import MyDatePicker from "./Date";
import { styled } from "@mui/material/styles";
import Paper from "@mui/material/Paper";
import "./aukcio.css";
import Menu from "../menu";
import Icon from "@mui/material/Icon";
import ImageIcon from "@mui/icons-material/Image";
//import AdapterDateFns from "@mui/lab/AdapterDateFns";
//import LocalizationProvider from "@mui/lab/LocalizationProvider";
//import DateTimePicker from "@mui/lab/DateTimePicker";

const MyItem = styled(Paper)(({ theme }) => ({
  ...theme.typography.body2,
  padding: theme.spacing(3),
  textAlign: "center",
  color: theme.palette.text.secondary,
}));

export default function Aukcio() {
  const [value, setValue] = React.useState(new Date());

  const handleImage = (event) => {
    console.log(event);
  };

  return (
    <Box>
      <Menu />
      <Box component="main">
        <Toolbar />
        <Grid container xs={12} height="100%">
          <Grid container xs={6} rowSpacing={2} columnSpacing={2}>
            <Grid item xs={12}>
              <h2>Aukció létrehozása</h2>
              <TextField sx={{ p: 1 }} label={"Aukció tárgya"} />
              <TextField
                sx={{ p: 1 }}
                multiline
                fullWidth
                rows={4}
                label={"Részletes leírása"}
              />
              <Box
                sx={{ p: 1 }}
                display="flex"
                justifyContent="center"
                alignItems="center"
                sx={{ border: "1px dashed grey" }}
                height="100px"
              >
                <Button variant="contained" component="label">
                  <Icon>
                    <ImageIcon />
                  </Icon>
                  <input type="file" hidden />
                </Button>
              </Box>
            </Grid>
          </Grid>

          <Grid container xs={6}>
            <Grid item xs={6}>
              <TextField
                variant="filled"
                size="small"
                sx={{ p: 1, ml: 4 }}
                label={"Kezdődátum"}
              />
              <TextField
                variant="filled"
                size="small"
                sx={{ p: 1, ml: 4 }}
                label={"Befejeződátum"}
              />
              <TextField
                variant="filled"
                size="small"
                sx={{ p: 1, ml: 4 }}
                label={"Kezdőlicit"}
              />
              <TextField
                variant="filled"
                size="small"
                sx={{ p: 1, ml: 4 }}
                label={"Licitlépcső"}
              />
            </Grid>
          </Grid>
          <Grid item xs={4}>
            <div className="akt_licit"></div>
          </Grid>
          <Grid item xs={8}>
            <div className="licit_btn">
              <Button variant="contained" color="primary">
                Aukció létrehozása
              </Button>
            </div>
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
}

/*                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DateTimePicker
                    renderInput={(props) => <TextField {...props} />}
                    label="DateTimePicker"
                    value={value}
                    onChange={(newValue) => {
                      setValue(newValue);
                    }}
                  />
                </LocalizationProvider>*/
