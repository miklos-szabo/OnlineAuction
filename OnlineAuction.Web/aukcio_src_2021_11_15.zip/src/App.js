import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";

import Licitalas from "./ui/licitalas/licit";
import Aukcio from "./ui/aukcio/aukcio";
import Aukciok_list from "./ui/aukciok_list/aukciok_list";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="" element={<Licitalas />} />
        <Route path="/aukcio" element={<Aukcio />} />
        <Route path="/licitalas" element={<Licitalas />} />
        <Route path="/aukciok_list" element={<Aukciok_list />} />
      </Routes>
    </Router>
  );
}
